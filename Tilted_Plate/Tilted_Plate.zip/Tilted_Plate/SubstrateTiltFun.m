function SubstrateTiltFun() 
     % Load data from the contours file
    temp = load('drop_sides.mat');
    leftsides = temp.leftsides;
    rightsides = temp.rightsides;
    
    % Get list of original images
    img_folder = pwd;
    img_extensions = {'.tif', '.png', '.jpg', '.jpeg', '.bmp', '.tiff'};
    img_files = [];
    for i = 1:length(img_extensions)
        img_files = [img_files; dir(fullfile(img_folder, ['*' img_extensions{i}]))];
    end
    if isempty(img_files)
        error('No images found in the directory.');
    end
    [~, idx] = sort({img_files.name});
    img_files = img_files(idx);
    
    numDroplets = numel(leftsides);
    if numel(img_files) ~= numDroplets
        warning('Number of images (%d) does not match number of droplets (%d).', numel(img_files), numDroplets);
        numDroplets = min(numel(img_files), numDroplets);
    end
    
    all_angles_roi = NaN(1, numDroplets);
    processed_data = struct();
    pct = 0.05;

    % Process each droplet for raw angle
    for n = 1:numDroplets
        data_left = leftsides(n).data;
        data_right = rightsides(n).data;
        [uxl, uyl] = process_contour(data_left, 'left');
        [uxr, uyr] = process_contour(data_right, 'right');
        [ptBL, ptBR, ang_roi] = detect_base_line(uxl, uyl, uxr, uyr, pct);
        all_angles_roi(n) = ang_roi;
        processed_data(n).ptBottomLeft = ptBL;
        processed_data(n).ptBottomRight = ptBR;
        processed_data(n).img_path = fullfile(img_folder, img_files(n).name);
    end
    
    % Continuous adjustment by average
    all_angles_filtered = adjust_angles_with_continuous_average(all_angles_roi);

    % GUI
    fig = figure('Name', 'Base Line on Images', 'Position', [100, 100, 1000, 800]);
    slider_step = [1/(numDroplets-1) 1/(numDroplets-1)];
    if numDroplets == 1, slider_step = [1 1]; end
    slider = uicontrol('Style', 'slider', ...
        'Min', 1, 'Max', numDroplets, 'Value', 1, ...
        'SliderStep', slider_step, ...
        'Position', [300 20 400 20], ...
        'Callback', @slider_callback);
    txt_droplet = uicontrol('Style', 'text', ...
        'Position', [300 45 400 20], ...
        'String', sprintf('Droplet 1 of %d', numDroplets), 'FontSize', 10);
    ax = axes('Position', [0.1 0.2 0.8 0.7]);
    show_image_with_line(1);
   %%
    uiwait(fig);  % Espera hasta que la figura se cierre
    export_csv();
    %% Internal functions
    function [x_unique, y_unique] = process_contour(data, side)
        x = data(:,1); y = data(:,2);
        [xs, idxs] = sort(x);
        ys = y(idxs);
        if strcmp(side, 'left')
            [~, iu] = unique(xs, 'last');
        else
            [~, iu] = unique(xs, 'first');
        end
        iu = sort(iu);
        x_unique = xs(iu); y_unique = ys(iu);
    end

    function [ptBL, ptBR, angle_roi] = detect_base_line(xl, yl, xr, yr, pct)
        contourPoints = [xl, yl; xr, yr];
        min_x = min(contourPoints(:,1));
        max_x = max(contourPoints(:,1));
        max_y = max(contourPoints(:,2));
        xLeftROI = min_x + 0.1*(max_x-min_x);
        xRightROI = max_x - 0.1*(max_x-min_x);
        yBottomROI = max_y - 0.1*(max_y - min(contourPoints(:,2)));
        N = size(contourPoints,1);
        nPointsROI = max(1, round(pct*N));

        [~, idxAsc] = sort(contourPoints(:,1), 'ascend');
        subsetBL = contourPoints(idxAsc(1:nPointsROI), :);
        distBL = sqrt((subsetBL(:,1)-xLeftROI).^2 + (subsetBL(:,2)-yBottomROI).^2);
        [~, idxMinBL] = min(distBL);
        ptBL = subsetBL(idxMinBL, :);

        [~, idxDesc] = sort(contourPoints(:,1), 'descend');
        subsetBR = contourPoints(idxDesc(1:nPointsROI), :);
        distBR = sqrt((subsetBR(:,1)-xRightROI).^2 + (subsetBR(:,2)-yBottomROI).^2);
        [~, idxMinBR] = min(distBR);
        ptBR = subsetBR(idxMinBR, :);

        dy = ptBR(2) - ptBL(2);
        dx = ptBR(1) - ptBL(1);
        angle_roi = atan2(dy, dx) * (180/pi);
        angle_roi = mod(angle_roi, 180);
        if abs(dy) < 1e-6, angle_roi = 0; end
        if angle_roi > 179.5, angle_roi = 0; end
        angle_roi = round(angle_roi, 2);
    end

    function adjusted = adjust_angles_with_continuous_average(angles)
        adjusted = angles;
        average_increment = 0;
        adjustment_activated = false;
        for i = 2:numel(angles)
              if ~adjustment_activated && (abs(adjusted(i-1) - angles(i)) > 1)
                % Activate adjustment from this point
                adjustment_activated = true;
                diffs = diff(adjusted(max(1,i-10):i-1));
                pos_diffs = diffs(diffs > 0);
                if ~isempty(pos_diffs)
                    average_increment = mean(pos_diffs);
                else
                    average_increment = 0;
                end
                adjusted(i) = adjusted(i-1) + average_increment;
            elseif adjustment_activated
                % Maintain correction in subsequent images
                adjusted(i) = adjusted(i-1) + average_increment;
            end
        end
    end


    function show_image_with_line(n)
        img = imread(processed_data(n).img_path);
        imshow(img, 'Parent', ax); hold(ax, 'on');
        % Original line (red)
        plot(ax, [processed_data(n).ptBottomLeft(1), processed_data(n).ptBottomRight(1)], ...
            [processed_data(n).ptBottomLeft(2), processed_data(n).ptBottomRight(2)], ...
            'r-', 'LineWidth', 2);
        % Corrected line (blue) - vertical displacement
        if all_angles_filtered(n) ~= all_angles_roi(n)
            dy = processed_data(n).ptBottomRight(2) - processed_data(n).ptBottomLeft(2);
            dx = processed_data(n).ptBottomRight(1) - processed_data(n).ptBottomLeft(1);
            m = dy/dx;
            new_m = tand(all_angles_filtered(n));
            x_vals = [processed_data(n).ptBottomLeft(1), processed_data(n).ptBottomRight(1)];
            y_vals = processed_data(n).ptBottomLeft(2) + new_m*(x_vals - x_vals(1));
            plot(ax, x_vals, y_vals, 'b--', 'LineWidth', 2);
        end
        title(ax, sprintf('Image %d - Adjusted: %.2f° | Original: %.2f°', ...
            n, all_angles_filtered(n), all_angles_roi(n)));
        hold(ax, 'off');
        set(txt_droplet, 'String', sprintf('Droplet %d of %d | Adj: %.2f° | Orig: %.2f°', ...
            n, numDroplets, all_angles_filtered(n), all_angles_roi(n)));
    end

    function slider_callback(src, ~)
        show_image_with_line(round(src.Value));
    end

    function export_csv()
    export_data = [(1:numDroplets)', all_angles_roi', all_angles_filtered'];
    titles = {'Image', 'Original_Angle', 'Adjusted_Angle'};
    table = array2table(export_data, 'VariableNames', titles);
    out_file = fullfile(img_folder, 'adjusted_angles.csv');
    writetable(table, out_file);
    fprintf('Archivo exportado automáticamente: %s\n', out_file);
    end
end