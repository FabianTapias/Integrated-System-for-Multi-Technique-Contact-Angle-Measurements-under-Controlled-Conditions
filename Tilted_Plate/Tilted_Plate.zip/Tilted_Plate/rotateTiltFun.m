function rotateTiltFun()
    clc;
    clear;
    close all;

    % %% Selection of folder with images
    % folderPath = uigetdir(pwd, 'Select the folder with images');
    % if folderPath == 0
    %     disp('No folder selected.');
    %     return;
    % end

    %% Use current folder
    folderPath = pwd;

    %% Read angles file
    % [angFile, angPath] = uigetfile('*.csv', 'Select the surface_angles.csv file');
    % if isequal(angFile,0)
    %     disp('No angles file selected.');
    %     return;
    % end
    % angDataRaw = readmatrix(fullfile(angPath, angFile)); % Read everything
    %% Read fixed angles file (adjusted_angles.csv in same folder)
    angFile = 'adjusted_angles.csv';
    angDataRaw = readmatrix(fullfile(folderPath, angFile));
    imgNumbers = angDataRaw(:,1);    % First column -> image number
    angles = angDataRaw(:,3);        % Third column -> adjusted angle

    %% Create folder for rotated images
    rotatedFolder = fullfile(folderPath, 'rotated_images');
    if ~exist(rotatedFolder, 'dir')
        mkdir(rotatedFolder);
    end

    %% Get list of TIFF images in the folder
    imgFiles = dir(fullfile(folderPath, '*.tif'));
    imgFiles = [imgFiles; dir(fullfile(folderPath, '*.tiff'))];

    if isempty(imgFiles)
        error('No TIFF images found in the selected folder.');
    end

    %% Process each image
    for k = 1:length(imgFiles)
        imgPath = fullfile(folderPath, imgFiles(k).name);
        img = imread(imgPath);

        % Find corresponding angle in adjusted_angles.csv
        idx = find(imgNumbers == k, 1); % Match image number with first column
        if isempty(idx)
            warning('No angle found for image %d (%s). Using 0°.', k, imgFiles(k).name);
            angleCCW = 0;
        else
            angleCCW = angles(idx); % Use column 3
        end

        % Rotate image with 'loose'
        rotatedImg = imrotate(img, angleCCW, 'bilinear', 'crop');

        % Fill black with white
        rotatedImg(rotatedImg == 0) = 255;

        % Center image on canvas of original size
        [h_orig, w_orig, ~] = size(img);
        [h_rot, w_rot, ~] = size(rotatedImg);

        canvas = 255 * ones(h_orig, w_orig, 'like', rotatedImg);

        startRow = floor((h_orig - h_rot)/2) + 1;
        startCol = floor((w_orig - w_rot)/2) + 1;

        rowIdx = max(1, startRow):max(1, startRow) + h_rot - 1;
        colIdx = max(1, startCol):max(1, startCol) + w_rot - 1;

        canvas(rowIdx, colIdx) = rotatedImg;
        rotatedImg = canvas;

        % Save rotated image
        [~, name, ext] = fileparts(imgFiles(k).name);
        outPath = fullfile(rotatedFolder, [name '_rotated' ext]);
        imwrite(rotatedImg, outPath);

        fprintf('✔ Image %s rotated %.2f° and saved at:\n%s\n', imgFiles(k).name, angleCCW, outPath);
    end

    disp('All images were processed and saved in the "rotated_images" folder.');
end