function [leftsides, rightsides, results] = ContourFun (varargin)
%PROCESSDROPIMAGES Processes drop images and extracts contours
%   [leftsides, rightsides, results] = processDropImages()
%   [leftsides, rightsides, results] = processDropImages('gaussianSigma', 1, 'folderPath', 'path/to/images')
%
%   Optional parameters:
%       'gaussianSigma' - Standard deviation for Gaussian filter (default: 1)
%       'folderPath'    - Path to folder with images (if not specified, uses uigetdir)

%% Default parameters
gaussianSigma = 1;
folderPath = '';

%% Process input parameters
for i = 1:2:length(varargin)
    switch lower(varargin{i})
        case 'gaussiansigma'
            gaussianSigma = varargin{i+1};
        case 'folderpath'
            folderPath = varargin{i+1};
        otherwise
            warning('Unknown parameter: %s', varargin{i});
    end
end

%% Select folder with images
if isempty(folderPath)
%Use folder of the currently running script
folderPath = fileparts(mfilename('fullpath'));
    %Choose a folder    
    % folderPath = uigetdir(pwd, 'Select folder with images');
    %     if folderPath == 0
    %         error('No folder selected.');
    %     end
end

allFiles = dir(folderPath);
validExt = {'.jpg', '.png', '.bmp', '.tif', '.tiff'};
getExt = @(f) lower(f(max(strfind(f, '.')):end));
imgFiles = allFiles(arrayfun(@(f) any(strcmpi(validExt, getExt(f.name))), allFiles));
imgFiles = imgFiles(~[imgFiles.isdir]);

if isempty(imgFiles)
    error('No images found in the selected folder.');
end

%% Read first and last image
firstImgPath = fullfile(folderPath, imgFiles(1).name);
lastImgPath = fullfile(folderPath, imgFiles(end).name);
firstImg = imread(firstImgPath);
lastImg = imread(lastImgPath);

%% ROI selection
figDrop = figure('Name', 'Drop ROI Selection', 'Position', [100 100 1200 500]);
subplot(1,2,1);
imshow(firstImg);
title('First Image - Select Drop ROI (Yellow)');
hDropROI1 = drawrectangle('Color', 'y', 'Label', 'Drop ROI');
subplot(1,2,2);
imshow(lastImg);
title('Last Image - Select Drop ROI (Yellow)');
hDropROI2 = drawrectangle('Color', 'g', 'Label', 'Drop ROI');

% Sync ROI movements
addlistener(hDropROI1, 'MovingROI', @(src, evt) syncROIs(src, hDropROI2));
addlistener(hDropROI1, 'ROIMoved', @(src, evt) syncROIs(src, hDropROI2));
addlistener(hDropROI2, 'MovingROI', @(src, evt) syncROIs(src, hDropROI1));
addlistener(hDropROI2, 'ROIMoved', @(src, evt) syncROIs(src, hDropROI1));

wait(hDropROI1);
dropROI = round(hDropROI1.Position);
close(figDrop);

%% Initialize structures
leftsides = struct('name', {}, 'data', {});
rightsides = struct('name', {}, 'data', {});
results = struct('filename', {}, 'contourPoints', {}, 'leftSide', {}, 'rightSide', {});

%% Image processing
for k = 1:length(imgFiles)
    fprintf('Processing image %d/%d: %s\n', k, length(imgFiles), imgFiles(k).name);
    imgPath = fullfile(folderPath, imgFiles(k).name);
    img = imread(imgPath);

    % Convert to grayscale if necessary
    if size(img, 3) == 3
        imgGray = rgb2gray(img);
    else
        imgGray = img;
    end

    % Crop region of interest (ROI)
    x1 = max(1, dropROI(1));
    y1 = max(1, dropROI(2));
    width = dropROI(3);
    height = dropROI(4);
    roiGray = imgGray(y1:y1+height-1, x1:x1+width-1);

    % Smoothing and binarization
    imgSmoothed = imgaussfilt(roiGray, gaussianSigma);
    threshold = graythresh(imgSmoothed);
    imgBinary = imbinarize(imgSmoothed, threshold);

    % Invert if necessary (background should be black)
    if sum(imgBinary(:)) > numel(imgBinary)/2
        imgBinary = ~imgBinary;
    end

    % Filter largest region (drop)
    imgCleaned = bwareafilt(imgBinary, 1);
    imgCleaned = imopen(imgCleaned, strel('disk', 10));

    % Detect contour
    contourEdges = bwperim(imgCleaned);
    [rows, cols] = find(contourEdges);
    imageHeight = size(roiGray, 1);
    imageWidth = size(roiGray, 2);
    validPoints = (cols > 1 & cols < imageWidth & rows > 1 & rows < imageHeight);
    validRows = rows(validPoints);
    validCols = cols(validPoints);
    absCols = validCols + x1 - 1;
    absRows = validRows + y1 - 1;
    contourPoints = [absCols, absRows];

    % Separate into left and right sides
    centerX = mean(contourPoints(:,1));
    leftSideAll = contourPoints(contourPoints(:,1) < centerX, :);
    rightSideAll = contourPoints(contourPoints(:,1) > centerX, :);
    leftSide = getLargestConnectedRegion(leftSideAll);
    rightSide = getLargestConnectedRegion(rightSideAll);

    % Save results
    results(k).filename = imgFiles(k).name;
    results(k).contourPoints = contourPoints;
    results(k).leftSide = leftSide;
    results(k).rightSide = rightSide;

    % Save in global structures
    leftsides(k).name = imgFiles(k).name;
    leftsides(k).data = leftSide;

    rightsides(k).name = imgFiles(k).name;
    rightsides(k).data = rightSide;

    % Optional: Quick visualization (useful visual crosscheck)
    % figure('Name', ['Contour - ' imgFiles(k).name]);
    % imshow(img); hold on;
    % rectangle('Position', dropROI, 'EdgeColor', 'y', 'LineWidth', 2);
    % plot(leftSide(:,1), leftSide(:,2), 'g.', 'MarkerSize', 6);
    % plot(rightSide(:,1), rightSide(:,2), 'r.', 'MarkerSize', 6);
    % title(['Detected contour - Image ' num2str(k)]);
    % legend('Left side', 'Right side');
end

%% Save global structures in .mat file
save('drop_sides.mat', 'leftsides', 'rightsides', 'results');

fprintf('Structures leftsides and rightsides saved in drop_sides.mat\n');

end

%% Helper functions

function syncROIs(src, targetROI)
    % Synchronize ROI positions
    targetROI.Position = src.Position;
end

function largestRegion = getLargestConnectedRegion(points)
    % Get the largest connected region from a set of points
    if isempty(points)
        largestRegion = points;
        return;
    end
    
    minX = floor(min(points(:,1)));
    minY = floor(min(points(:,2)));
    maxX = ceil(max(points(:,1)));
    maxY = ceil(max(points(:,2)));
    
    tempImg = false(maxY - minY + 1, maxX - minX + 1);
    relX = round(points(:,1)) - minX + 1;
    relY = round(points(:,2)) - minY + 1;
    
    ind = sub2ind(size(tempImg), relY, relX);
    tempImg(ind) = true;
    
    CC = bwconncomp(tempImg, 8);
    numPixels = cellfun(@numel, CC.PixelIdxList);
    [~, idxLargest] = max(numPixels);
    
    largestInds = CC.PixelIdxList{idxLargest};
    [Y, X] = ind2sub(size(tempImg), largestInds);
    
    absX = X + minX - 1;
    absY = Y + minY - 1;
    largestRegion = [absX, absY];
end