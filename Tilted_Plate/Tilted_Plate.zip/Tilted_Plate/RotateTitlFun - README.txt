===========================================
README – rotateTiltFun Workflow Description
===========================================

Overview
--------
rotateTiltFun is a processing step used in the tilted-substrate droplet analysis workflow. Its purpose is to automatically rotate each droplet image so that the substrate becomes horizontally aligned. This ensures that the drop is analyzed in a consistent orientation during subsequent contour and contact-angle evaluations.

This function relies on the surface tilt angles previously computed using SubstrateTiltFun. It uses these angles to "correct" every image by rotating it in the opposite direction of the measured tilt.

Input Requirements
------------------
The function expects:
1. A folder containing the original TIFF droplet images.
2. A file named "adjusted_angles.csv" in the same folder.
   - This file must contain:
     * Column 1: Image index (1, 2, 3, ...)
     * Column 3: Corrected substrate angles to be used for rotation

If the CSV file or the TIFF images are missing, the function will stop and notify the user.

Output
------
rotateTiltFun generates:
- A new folder called "rotated_images"
- All input images rotated such that their baseline is horizontal
- The rotated images preserve the naming of the originals but include "_rotated" in the filename

Workflow Summary
----------------
1. Load the adjusted substrate angles
   The function reads the file "adjusted_angles.csv", extracting corrected tilt values for each image.

2. Detect and load all TIFF images
   The function automatically searches for ".tif" and ".tiff" files in the working directory.

3. Match each image to its corresponding tilt angle
   Image numbers are matched to the first column of the angles file.
   If no match is found, the image is rotated by 0°.

4. Rotate each image
   Each image is rotated by its corresponding corrected angle:
   - Rotation is counter-clockwise.
   - The rotation aligns the substrate horizontally.
   - A "crop" method is used, and black background pixels created by rotation are replaced with white.

5. Recenter the rotated image
   After rotation:
   - Images may shrink due to cropping.
   - The function automatically centers the rotated image inside a white canvas matching the original image size.
   This ensures that the final dataset keeps uniform dimensions.

6. Save rotated images
   All corrected images are saved into the "rotated_images" folder.
   The naming convention preserves the original file name but adds "_rotated" before the extension.

Purpose in the Complete Workflow
--------------------------------
rotateTiltFun is essential for ensuring that all subsequent droplet analyses are performed on horizontally aligned images. This correction eliminates artificial angle variations caused by camera tilt or substrate misalignment.

This function is typically called after:
1. Contour extraction (ContourFun)
2. Substrate tilt estimation (SubstrateTiltFun)

Only after rotation can the droplet evaluation step (CATiltFun) be reliably performed on properly aligned images.

-------------------------------------------
End of README for rotateTiltFun
-------------------------------------------
