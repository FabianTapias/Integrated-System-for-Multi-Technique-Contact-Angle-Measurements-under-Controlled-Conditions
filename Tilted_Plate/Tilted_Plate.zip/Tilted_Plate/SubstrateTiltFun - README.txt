SubstrateTiltFun - README

Overview

This MATLAB function SubstrateTiltFun processes droplet contour data to
detect substrate tilt angles, corrects angle inconsistencies using a
continuous average method, and displays results in a GUI for
visualization. It also exports a CSV file containing original and
adjusted angles.

The script: - Loads droplet contour data from drop_sides.mat - Loads
corresponding images from the working directory - Extracts and filters
contour points - Determines baseline points for each droplet -
Calculates tilt angles - Applies continuous correction for inconsistent
jumps - Displays results with a slider-based viewer - Automatically
exports adjusted_angles.csv

------------------------------------------------------------------------

Requirements

-   MATLAB (recommended R2020a or newer)
-   File drop_sides.mat in the same directory
    Must contain:
    -   leftsides(n).data → Nx2 arrays
    -   rightsides(n).data → Nx2 arrays
-   Droplet images in the same folder (.tif, .png, .jpg, .jpeg, .bmp,
    .tiff)

------------------------------------------------------------------------

How it Works

1. Data Loading

The function loads contour data and searches for images in the folder.
It ensures the number of images matches the number of droplets.

2. Contour Processing

The internal function process_contour: - Sorts points by x-coordinate -
Keeps the last unique x-values for the left side - Keeps the first
unique x-values for the right side

3. Baseline Detection

detect_base_line: - Merges left and right contour points - Defines a
region of interest at the bottom of the droplet - Selects the closest
point to predetermined ROI bounds for left and right base points -
Computes the baseline angle with atan2

4. Angle Correction

adjust_angles_with_continuous_average: - Detects sudden angle drops >
1° - Computes an average positive increment and smooths the sequence -
Ensures progressive, consistent tilt evolution

5. GUI Visualization

A MATLAB figure is created with: - Slider to navigate droplets - Red
line → detected baseline
- Blue dashed line → corrected baseline - Title and text labels showing
angles

6. CSV Export

The script exports:

    Image | Original_Angle | Adjusted_Angle

into adjusted_angles.csv.

------------------------------------------------------------------------

Output Files

-   adjusted_angles.csv
    CSV with each image index, original angle, and corrected angle.

------------------------------------------------------------------------

Usage

Simply run:

    SubstrateTiltFun

Ensure that: - drop_sides.mat is in the same directory - Images are in
the same directory - MATLAB has permission to create files

------------------------------------------------------------------------

Notes

-   If only one image is present, slider step is automatically adjusted.
-   The function pauses (uiwait) until the GUI is closed.
-   Adjustments only start after a detected inconsistency.

------------------------------------------------------------------------

Author

Automatically generated README for your MATLAB substrate tilt detection
tool.
