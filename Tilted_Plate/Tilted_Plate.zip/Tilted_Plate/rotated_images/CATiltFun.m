function CATiltFun()
% --- Parameters ---%%
percentage_contour=0.1;                 % Define the percentage of the total number of points in each side to be considered for the determinacion of contact angle

%Calculate slopes using cross product
range = 3;                              %Define the number of consecutive points in each contorn to be used for the calculation of slope through crossproduct (It will define how sensitive is your algoritm to abrut changes in slope), defaul=1
% Left and right thresholds - using cross product
slope_lft=0.5;                          %Define the slope threshold in the left contour, which the algortim will cover to automatically detect abrupt changes
pos_x_lft=1300;                         %Define the coordinate in X in the left contour, which the algotitm will cover to automatically detect abrupt changes
slope_rgt=-0.7;                         %Define the slope threshold in the rigght contour, which the algortim will cover to automatically detect abrupt changes
pos_x_rgt=4300;                         %Define the coordinate in X in the rigght contour, which the algotitm will cover to automatically detect abrupt changes    
    
    %% Load data from the global file using a temporary structure
    temp = load('drop_sides.mat');
    leftsides = temp.leftsides;
    rightsides = temp.rightsides;

    % Number of available droplets
    numDroplets = numel(leftsides);

     %% Read angles file
    %% Read angles file (adjusted_angles.csv in the same folder)
    angFile = 'adjusted_angles.csv';
    angPath = pwd;  % current folder
    if ~exist(fullfile(angPath, angFile), 'file')
        error('File %s not found in the current folder.', angFile);
    end
         
    %  [angFile, angPath] = uigetfile('*.csv', 'Select the surface_angles.csv file');
    % if isequal(angFile,0)
    %     disp('No angles file selected.');
    %     return;
    % end

    angDataRaw = readmatrix(fullfile(angPath, angFile)); % Read everything
    imgNumbers = angDataRaw(:,1);    % First column -> image number
    if size(angDataRaw,2) >= 3
        angles_csv = angDataRaw(:,3);
    else
        angles_csv = NaN(size(angDataRaw,1),1);
    end

%%
    % Initialize vectors to store angles and fitting data
    all_angles_left = NaN(1, numDroplets);
    all_angles_right = NaN(1, numDroplets);
 
    % Store all processed data for each droplet
    processed_data = struct();

    % Parameters for ROI analysis
    pct = 0.05; % Percentage of points to consider for extremes
    
    for n = 1:numDroplets
        fprintf('\n======= Processing Droplet %d: %s =======\n', n, leftsides(n).name);

        %% Load data
        data_left = leftsides(n).data;
        data_right = rightsides(n).data;
        %% Scan from top to bottom
        %--- Left contour ---
        % Extract X and Y coordinates from the left contour
        x_left = data_left(:,1);  % X column
        y_left = data_left(:,2);  % Y column
        % Sort X from smallest to largest and save the order indices
        [x_left_sorted, sort_idx_left] = sort(x_left);
        % Reorder Y according to the order of X
        y_left_sorted = y_left(sort_idx_left);
        % Remove duplicate X values, keeping the first value found from right to left
        [~, idx_unique] = unique(x_left_sorted, 'last');  % Use 'last' to keep the last duplicate (which will be the first when inverted)
        idx_unique = sort(idx_unique);  % Sort the indices to maintain the original order
        unique_x_left = x_left_sorted(idx_unique);
        unique_y_left = y_left_sorted(idx_unique);
        
        %% --- Right contour ---
        % Extract X and Y coordinates from the right contour
        x_right = data_right(:,1);  % X column
        y_right = data_right(:,2);  % Y column
        % Sort X from smallest to largest and save the order indices
        [x_right_sorted, sort_idx_right] = sort(x_right);
        % Reorder Y according to the order of X
        y_right_sorted = y_right(sort_idx_right);
        % Remove duplicate X values, keeping the first value found from left to right
        [unique_x_right, idx_unique] = unique(x_right_sorted, 'first');  % 'first' is the default behavior
        unique_y_right = y_right_sorted(idx_unique);

        %% Calculate slopes using cross product
        step = range;
        % Left - using cross product
        slopes_left = [];
        positions_x_left = [];
        for i = 1:step:(length(unique_x_left)-step)
            p1 = [unique_x_left(i); unique_y_left(i)];
            p2 = [unique_x_left(i+step); unique_y_left(i+step)];
            v = p2 - p1;
            v_ref = [1; 0];
            cross_z = v(1)*v_ref(2) - v(2)*v_ref(1);
            m = cross_z / max(v(1), eps);
            slopes_left(end+1) = m;
            positions_x_left(end+1) = p1(1);
        end
        left_contact_idx = find(slopes_left >slope_lft & positions_x_left > pos_x_lft, 1, 'first');
        if ~isempty(left_contact_idx)
            x_left_contact = positions_x_left(left_contact_idx);
            y_left_contact = interp1(unique_x_left, unique_y_left, x_left_contact, 'nearest');
        else
            x_left_contact = [];
            y_left_contact = [];
        end

        % Right - using cross product
        slopes_right = [];
        positions_x_right = [];
        for i = 1:step:(length(unique_x_right)-step)
            p1 = [unique_x_right(i); unique_y_right(i)];
            p2 = [unique_x_right(i+step); unique_y_right(i+step)];
            v = p2 - p1;
            v_ref = [1; 0];
            cross_z = v(1)*v_ref(2) - v(2)*v_ref(1);
            m = cross_z / max(v(1), eps);
            slopes_right(end+1) = m;
            positions_x_right(end+1) = p1(1);
        end
        right_contact_idx = find(slopes_right <slope_rgt & positions_x_right < pos_x_rgt, 1, 'last');
        if ~isempty(right_contact_idx)
            contact_idx = right_contact_idx + 1;
            x_right_contact = positions_x_right(min(contact_idx, end));
            y_right_contact = interp1(unique_x_right, unique_y_right, x_right_contact, 'nearest');
        else
            x_right_contact = [];
            y_right_contact = [];
        end

        %% Fits and angles
        % Left
        if ~isempty(x_left_contact)  % Check if the left contact point was found
          % Find the index of the point in unique_x_left closest to x_left_contact
         [~, idx_contact] = min(abs(unique_x_left - x_left_contact));
          % Define the number of points for the fit (10% of the total)
          n_points = round(percentage_contour * length(unique_x_left));
          % Final index for the fit (avoid going beyond the end of the vector)
          end_idx = min(length(unique_x_left), idx_contact + n_points);
          % Selection of points (X, Y) for the parabolic fit
          x_fit_left = unique_x_left(idx_contact:end_idx);
          y_fit_left = unique_y_left(idx_contact:end_idx);
          % Design matrix for quadratic fit: y = a*x^2 + b*x + c
          X = [x_fit_left.^2, x_fit_left, ones(size(x_fit_left))];
          % Calculate the coefficients [a, b, c] using least squares
          coeff_left = X \ y_fit_left;
          % Calculate the slope of the parabola at the contact point
          slope_left = 2 * coeff_left(1) * x_left_contact + coeff_left(2);
          % Convert the slope to angle in degrees (absolute value)
         angle_left_deg = abs(atand(slope_left));
         % Generate points to plot the fitted curve
         x_plot_left = linspace(min(x_fit_left), max(x_fit_left), 100);
         y_plot_left = coeff_left(1)*x_plot_left.^2 + coeff_left(2)*x_plot_left + coeff_left(3);
         else
            % If no contact point, leave everything empty or NaN
            angle_left_deg = NaN;
            x_plot_left = [];
            y_plot_left = [];
        end
        % Right
        if ~isempty(x_right_contact)
            [~, idx_contact] = min(abs(unique_x_right - x_right_contact));
            n_points = round(percentage_contour * length(unique_x_right));
            start_idx = max(1, idx_contact - n_points);
            x_fit_right = unique_x_right(start_idx:idx_contact);
            y_fit_right = unique_y_right(start_idx:idx_contact);
            X = [x_fit_right.^2, x_fit_right, ones(size(x_fit_right))];
            coeff_right = X \ y_fit_right;
            slope_right = 2 * coeff_right(1) * x_right_contact + coeff_right(2);
            angle_right_deg = abs(atand(slope_right));
            x_plot_right = linspace(min(x_fit_right), max(x_fit_right), 100);
            y_plot_right = coeff_right(1)*x_plot_right.^2 + coeff_right(2)*x_plot_right + coeff_right(3);
        else
            angle_right_deg = NaN;
            x_plot_right = [];
            y_plot_right = [];
        end
        %% Save results
        % Angle relative to X
        all_angles_left(n) = angle_left_deg;
        all_angles_right(n) = angle_right_deg;
        %all_angles_roi(n) = angle_roi; 
        %%          
         % Get angle from CSV for this image (optional)
                idx_csv = find(imgNumbers == n, 1);
                if ~isempty(idx_csv)
                    angle_csv = angles_csv(idx_csv);
                else
                    angle_csv = NaN;
                end
        %%
        processed_data(n).unique_x_left = unique_x_left;
        processed_data(n).unique_y_left = unique_y_left;
        processed_data(n).unique_x_right = unique_x_right;
        processed_data(n).unique_y_right = unique_y_right;
        processed_data(n).x_left_contact = x_left_contact;
        processed_data(n).y_left_contact = y_left_contact;
        processed_data(n).x_plot_left = x_plot_left;
        processed_data(n).y_plot_left = y_plot_left;
        processed_data(n).x_right_contact = x_right_contact;
        processed_data(n).y_right_contact = y_right_contact;
        processed_data(n).x_plot_right = x_plot_right;
        processed_data(n).y_plot_right = y_plot_right;
        processed_data(n).positions_x_left = positions_x_left;
        processed_data(n).slopes_left = slopes_left;
        processed_data(n).positions_x_right = positions_x_right;
        processed_data(n).slopes_right = slopes_right;
        processed_data(n).angle_left_deg = angle_left_deg;
        processed_data(n).angle_right_deg = angle_right_deg;
        
    end
%% Polynomial fit using only valid points (angles_csv > 0.05)
% Find valid indices
idx_valid = find(angles_csv > 0.05);

% --- Fit for left angles ---
x_left_fit = angles_csv(idx_valid);          % X axis = tilt angles
y_left_fit = all_angles_left(idx_valid);     % Y axis = left angles
p_left = polyfit(x_left_fit, y_left_fit, 2); % quadratic polynomial

% Generate line for plotting (100 points between min and max)
x_left_plot = linspace(min(x_left_fit), max(x_left_fit), 100);
y_left_plot = polyval(p_left, x_left_plot);

% --- Fit for right angles ---
x_right_fit = angles_csv(idx_valid);
y_right_fit = all_angles_right(idx_valid);
p_right = polyfit(x_right_fit, y_right_fit, 2);

x_right_plot = linspace(min(x_right_fit), max(x_right_fit), 100);
y_right_plot = polyval(p_right, x_right_plot);

% --- Display equations and metrics ---
fprintf('Left Polyfit: y = %.4f x^2 + %.4f x + %.4f\n', p_left(1), p_left(2), p_left(3));
fprintf('Right Polyfit: y = %.4f x^2 + %.4f x + %.4f\n', p_right(1), p_right(2), p_right(3));

% RMSE AND R² CALCULATION
% Ensure they are column vectors
x_left_fit = x_left_fit(:); y_left_fit = y_left_fit(:);
x_right_fit = x_right_fit(:); y_right_fit = y_right_fit(:);

% Predictions at the same fitting points
y_left_pred = polyval(p_left, x_left_fit);
y_right_pred = polyval(p_right, x_right_fit);

% RMSE for each function
rmse_left = sqrt(mean((y_left_fit - y_left_pred).^2));
rmse_right = sqrt(mean((y_right_fit - y_right_pred).^2));

% R² for each function
r2_left = 1 - sum((y_left_fit - y_left_pred).^2) / sum((y_left_fit - mean(y_left_fit)).^2);
r2_right = 1 - sum((y_right_fit - y_right_pred).^2) / sum((y_right_fit - mean(y_right_fit)).^2);

% Show results
fprintf('RMSE Left: %.4f, R² left: %.4f\n', rmse_left, r2_left);
fprintf('RMSE Right: %.4f, R² right: %.4f\n', rmse_right, r2_right);

        %% Create figure with slider
    fig = figure('Name', 'Droplet Visualization with Slider', 'Position', [100, 100, 1200, 800]);
    
    % Create slider
    slider = uicontrol('Style', 'slider', ...
        'Min', 1, 'Max', numDroplets, 'Value', 1, ...
        'SliderStep', [1/(numDroplets-1) 1/(numDroplets-1)], ...
        'Position', [100 20 200 20], ...
        'Callback', @slider_callback);
    
    % Text to show the droplet number
    txt_droplet = uicontrol('Style', 'text', ...
        'Position', [300 20 100 20], ...
        'String', sprintf('Droplet 1 of %d', numDroplets), ...
        'FontSize', 10);
    
    % Button to export to CSV
    btn_export = uicontrol('Style', 'pushbutton', ...
        'String', 'CSV Export', ...
        'Position', [820 20 120 20], ...
        'Callback', @export_csv);
    
    % Create subplots
    ax1 = subplot(3,1,1);
    ax2 = subplot(3,1,2);
    ax3 = subplot(3,1,3);
       
%% Nested functions 
function export_csv(~, ~)
        % Ensure the CSV column has length numDroplets
        angles_csv_full = NaN(1,numDroplets);
        k = min(numDroplets, numel(angles_csv));
        if k > 0
            angles_csv_full(1:k) = angles_csv(1:k);
        end
    % --- Complete matrix ---
    export_data = [
        (1:numDroplets)', ...        % Droplet / image number
        all_angles_left', ...     % Left angle
        all_angles_right', ...    % Right angle
        angles_csv_full'
    ];

    % --- Second matrix only with ROI ---
    roi_data = [
        (1:numDroplets)', ...
        angles_csv_full'
    ];

    % --- Create table for complete CSV ---
    titles = {'Image', 'Left_Angle', 'Right_Angle', 'Substrate_Angle'};
    complete_table = array2table(export_data, 'VariableNames', titles);

    % --- Save complete CSV ---
    [filename, path] = uiputfile('*.csv', 'Save complete CSV file', 'complete_angles.csv');
    if filename ~= 0
        complete_file = fullfile(path, filename);
        writetable(complete_table, complete_file);
        fprintf('✔ Complete CSV saved at: %s\n', complete_file);
    end
end

    %% Function to update the plots
    function slider_callback(source, ~)
        n = round(source.Value);
        update_plots(n);
    end
    
    function update_plots(n)
        % Update text
        set(txt_droplet, 'String', sprintf('Droplet %d of %d', n, numDroplets));
        
        % Subplot 1: contours and fits
        cla(ax1);
        plot(ax1, processed_data(n).unique_x_left, processed_data(n).unique_y_left, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Left Side');
        % see the original shape: plot(ax1, x_left_sorted, y_left_sorted, 'b.', 'MarkerSize', 8, 'DisplayName', 'Left contour'); 
        hold(ax1, 'on');
        plot(ax1, processed_data(n).unique_x_right, processed_data(n).unique_y_right, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Right Side');
        % see the original shape: plot(ax1,x_right_sorted, y_right_sorted, 'k.', 'MarkerSize', 8, 'DisplayName', 'Right contour');
        hold(ax1, 'on');
       
        % Contact point markers
        if ~isempty(processed_data(n).x_left_contact)
            plot(ax1, processed_data(n).x_left_contact, processed_data(n).y_left_contact, 'g>', 'MarkerSize', 10, 'DisplayName', 'Left Contact'); 
        end
        if ~isempty(processed_data(n).x_plot_left)
            plot(ax1, processed_data(n).x_plot_left, processed_data(n).y_plot_left, 'c', 'LineWidth', 2, 'DisplayName', 'Left fit'); 
        end
        if ~isempty(processed_data(n).x_right_contact)
            plot(ax1, processed_data(n).x_right_contact, processed_data(n).y_right_contact, 'go', 'MarkerSize', 10, 'DisplayName', 'Right Contact'); 
        end
        if ~isempty(processed_data(n).x_plot_right)
            plot(ax1, processed_data(n).x_plot_right, processed_data(n).y_plot_right, 'm', 'LineWidth', 2, 'DisplayName', 'Right fit'); 
        end
        
        % Graph configuration
        xlabel(ax1, 'X'); ylabel(ax1, 'Y'); 
        title(ax1, sprintf('Contour - Droplet %d | Tilt Angle: %.2f°', n, angles_csv(n))); 
        legend(ax1, 'Location', 'best');
        set(ax1, 'YDir', 'reverse'); grid(ax1, 'on');

        % Subplot 2: slopes
        cla(ax2);
        stem(ax2, processed_data(n).positions_x_left, processed_data(n).slopes_left, 'b', 'DisplayName', 'Left'); 
        hold(ax2, 'on');
        stem(ax2, processed_data(n).positions_x_right, processed_data(n).slopes_right, 'r', 'DisplayName', 'Right');
        xlabel(ax2, 'X'); ylabel(ax2, 'Slope');
        title(ax2, 'Slope (Vectorial Product)'); 
        legend(ax2); grid(ax2, 'on');
        %%
        % Subplot 3: accumulated angles in function of tilt
         cla(ax3);
        % Find valid indices
        idx_valid = find(angles_csv > 0.05);

        if ~isempty(idx_valid)

            % Plot only that point
            plot(ax3, angles_csv(idx_valid), all_angles_left(idx_valid), 'bo', ...
                'DisplayName', 'Left Angle', 'MarkerSize', 8, 'LineWidth', 1.5);  
            hold(ax3, 'on');
            plot(ax3, angles_csv(idx_valid), all_angles_right(idx_valid), 'ro', ...
                'DisplayName', 'Right Angle', 'MarkerSize', 8, 'LineWidth', 1.5);

            % Highlight the current point (n) if it matches last_idx
            if ismember(n, idx_valid)
                    plot(ax3, angles_csv(n), all_angles_left(n), 'bo', ...
                    'MarkerSize', 10, 'LineWidth', 2);
                    plot(ax3, angles_csv(n), all_angles_right(n), 'ro', ...
                     'MarkerSize', 10, 'LineWidth', 2);;
            end
        end

        % Plot fit lines over the data
        plot(ax3, x_left_plot, y_left_plot, 'b--', 'LineWidth', 2, 'DisplayName', 'Left Fit');
        plot(ax3, x_right_plot, y_right_plot, 'r--', 'LineWidth', 2, 'DisplayName', 'Right Fit');

        xlabel(ax3, 'Tilt Angle (°)');
        ylabel(ax3, 'Contact Angle (°)');
        title(ax3, 'Contact Angle in function of tilt angle');
        legend(ax3, 'Location', 'best'); 
        grid(ax3, 'on');

    end

    % Show the first droplet at startup
    update_plots(1);
end