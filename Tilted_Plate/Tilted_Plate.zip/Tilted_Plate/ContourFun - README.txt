ContourFun - README

General Description
===================
ContourFun is a MATLAB function designed to automate the processing of droplet images and extract left and right contour profiles for later contact-angle analysis.
The algorithm applies ROI-based cropping, Gaussian smoothing, adaptive thresholding, segmentation, contour detection, and connected-component filtering to obtain clean and physically meaningful droplet boundaries.
The function outputs three structured variables containing contour data for all images in the selected folder.

Function Signature
==================
[leftsides, rightsides, results] = ContourFun()
[leftsides, rightsides, results] = ContourFun('gaussianSigma', 1.5, 'folderPath', 'path/to/images')

Configurable Parameters
=======================
Optional Name–Value Inputs:

gaussianSigma  
    Standard deviation used in Gaussian filtering.
    Higher values increase smoothing but may blur edges.
    Default: 1

folderPath  
    Path to the directory containing droplet images.
    If omitted, the function uses the current script directory.
    A manual folder selection dialog is included but disabled by default.

Supported image formats: .jpg, .png, .bmp, .tif, .tiff

What These Parameters Do
------------------------
gaussianSigma: Controls noise reduction before thresholding.  
folderPath: Defines the dataset location and avoids repeated GUI selection.

How the Code Works
==================

1. Input Parsing
   - Reads optional parameters and applies defaults.
   - Warns if an unknown parameter is supplied.

2. Folder & File Handling
   - Uses the provided folder or the script’s directory.
   - Scans for image files with supported extensions.
   - Sorts and validates the detected file list.

3. ROI (Region of Interest) Selection
   - Displays the first and last image in the dataset.
   - User draws a rectangle defining the droplet region.
   - Two ROIs remain synchronized during adjustments.
   - The confirmed ROI is applied to every image.

4. Image Processing Pipeline
   For each image:
   - Convert to grayscale if necessary.
   - Crop using the selected ROI.
   - Apply Gaussian smoothing (gaussianSigma).
   - Compute adaptive threshold (graythresh).
   - Binarize the image (imbinarize).
   - Invert if needed (droplet must be white).
   - Extract only the largest region (the droplet).
   - Apply morphological opening for cleanup.

5. Contour Extraction
   - Detect the droplet perimeter with bwperim.
   - Convert ROI coordinates back to global coordinates.
   - Compute the horizontal centroid and split the contour into:
        Left side
        Right side
   - Keep only the largest connected region on each side.

6. Result Storage
   - leftsides(k).data  → left contour points of image k
   - rightsides(k).data → right contour points of image k
   - results(k).contourPoints, leftSide, rightSide, filename
   - All variables are automatically saved into:
        drop_sides.mat

Exported Files
==============
1. drop_sides.mat (automatically generated)
   Contains:
   - leftsides
   - rightsides
   - results

These outputs are intended for downstream contact-angle analysis scripts such as RotateDropProfiles.m and CABubbleFun_Hydrophobic.m.

Usage Summary
=============

1. Prepare Image Folder:
   - Place all droplet images in a single directory.
   - Use only supported file extensions.

2. Run the Function:
   ContourFun();
   Or with custom settings:
   ContourFun('gaussianSigma', 2, 'folderPath', 'C:/drops/run01');

3. Expected Output:
   ✓ Automatic contour detection for all images  
   ✓ Saved variables leftsides, rightsides, results  
   ✓ drop_sides.mat in the working directory  
   ✓ Clean left/right contour separation for each droplet

4. Notes:
   - ROI selection happens only once at the start.
   - The extracted contours serve as input for subsequent angle-fitting algorithms.

